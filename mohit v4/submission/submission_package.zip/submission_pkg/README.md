# Traffic Demand Forecasting v4
Time-based CV, K-fold target encoding, CatBoost/LightGBM/XGBoost ensemble, Highway calibration, RoadType bounds.
